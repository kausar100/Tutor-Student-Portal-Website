﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class LoginPage : System.Web.UI.Page
    {
        
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\UserInfo.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["UserDetails"];
            if (cookie != null)
            {
                //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");
                Response.Redirect("student_homepage.html");
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             string acc = DropDownList1.SelectedItem.ToString();
             if (acc == "STUDENT")
             {
                 string check = "select count(*) from [Student] where userName =  '" + userID.Text + "' and passWord = '" + passwordID.Text + "' ";
                 SqlCommand command = new SqlCommand(check, conn);
                 conn.Open();
                 int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                 conn.Close();
                 if (temp == 1)
                 {

                     if (CheckBox1.Checked == true)
                     {
                         HttpCookie cookie = new HttpCookie("UserDetails");
                         cookie["fName"] = userID.Text;
                         cookie["lName"] = passwordID.Text;
                         //cookie.Expires = DateTime.Now.AddDays(30);
                         Response.Cookies.Add(cookie);
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");
                         Response.Redirect("student_homepage.html");


                     }
                     else
                     {
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");                    
                         Response.Redirect("student_homepage.html");


                     }
                 }
                 else
                 {
                     Response.Write("<script>alert('Your Username or Password is Invalid');</script>");
                     //Label4.Visible = true;
                     //Label4.Text = "Your Username or Password is Invalid";

                 }
             }
             else if (acc == "TUTOR")
             {
                 string check = "select count(*) from [Tutor] where userName =  '" + userID.Text + "' and passWord = '" + passwordID.Text + "' ";
                 SqlCommand command = new SqlCommand(check, conn);
                 conn.Open();
                 int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                 conn.Close();
                 if (temp == 1)
                 {

                     if (CheckBox1.Checked == true)
                     {
                         HttpCookie cookie = new HttpCookie("UserDetails");
                         cookie["fName"] = userID.Text;
                         cookie["lName"] = passwordID.Text;
                         //cookie.Expires = DateTime.Now.AddDays(30);
                         Response.Cookies.Add(cookie);
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");
                         Response.Redirect("tutor_homepage.html");


                     }
                     else
                     {
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");                    
                         Response.Redirect("tutor_homepage.html");


                     }
                 }
                 else
                 {
                     Response.Write("<script>alert('Your Username or Password is Invalid');</script>");
                     //Label4.Visible = true;
                     //Label4.Text = "Your Username or Password is Invalid";

                 }
             }
             else
             {
                 string check = "select count(*) from [Admin] where userName =  '" + userID.Text + "' and passWord = '" + passwordID.Text + "' ";
                 SqlCommand command = new SqlCommand(check, conn);
                 conn.Open();
                 int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                 conn.Close();
                 if (temp == 1)
                 {

                     if (CheckBox1.Checked == true)
                     {
                         HttpCookie cookie = new HttpCookie("UserDetails");
                         cookie["fName"] = userID.Text;
                         cookie["lName"] = passwordID.Text;
                         //cookie.Expires = DateTime.Now.AddDays(30);
                         Response.Cookies.Add(cookie);
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");
                         Response.Redirect("admin_homepage.html");


                     }
                     else
                     {
                         //Response.Write("<script>alert('YOU HAVE SUCCESSFULLY LOG IN');</script>");                    
                         Response.Redirect("admin_homepage.html");


                     }
                 }
                 else
                 {
                     Response.Write("<script>alert('Your Username or Password is Invalid');</script>");
                     //Label4.Visible = true;
                     //Label4.Text = "Your Username or Password is Invalid";

                 }
             }

            
        }
    }
}