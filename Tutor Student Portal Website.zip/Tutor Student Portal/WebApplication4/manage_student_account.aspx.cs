﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication4
{
    public partial class manage_student_account : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\UserInfo.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            //conn.Open();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string check = "select count(*) from [Student] where userName =  '" + userID.Text + "' and Email_id='" + email.Text + "'";
            SqlCommand command = new SqlCommand(check, conn);
            conn.Open();
            int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
            conn.Close();
            if (temp == 1)
            {
                SqlCommand cmd = conn.CreateCommand();
                conn.Open();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from Student where userName= '" + userID.Text + "' AND Email_id='" + email.Text + "'";
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('ACCOUNT DELETED SUCCESSFULLY');</script>");
                userID.Text = "";
                email.Text = "";
            }
            else
            {
                Response.Write("<script>alert('INVALID USERNAME OR EMAIL ID..');</script>");
            }
        }
    }
}