﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace WebApplication4
{
    public partial class request_a_tutor : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\UserInfo.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string dst = DropDownList1.SelectedItem.ToString();
            string ar = DropDownList2.SelectedItem.ToString();
            string mdm = DropDownList3.SelectedItem.ToString();
            string cls = DropDownList4.SelectedItem.ToString();
            string sub = DropDownList5.SelectedItem.ToString();
            string dpw = DropDownList6.SelectedItem.ToString();
            string gos = DropDownList7.SelectedItem.ToString();
            string dtg = DropDownList8.SelectedItem.ToString();
            string sr = DropDownList9.SelectedItem.ToString();

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Student_tution_table values ('" + TextBox1.Text + "','" + dst + "','" + ar + "','" + mdm + "','" + cls + "','" + sub + "','" + dpw + "','" + gos + "','" + dtg + "','" + sr + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
            conn.Open();
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            Response.Write("<script>alert('REQUEST SUBMITTED SUCCESSFULLY');</script>");
        }
    }
}