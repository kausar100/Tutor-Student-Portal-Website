﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication4
{
    public partial class give_feedback : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\UserInfo.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string mdm = DropDownList3.SelectedItem.ToString();
            string cls = DropDownList4.SelectedItem.ToString();
            string sub = DropDownList5.SelectedItem.ToString();

            string rt = DropDownList8.SelectedItem.ToString();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Feedback_table values ('" + TextBox1.Text + "','" + mdm + "','" + cls + "','" + sub + "','" + rt + "')";
            conn.Open();
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            Response.Write("<script>alert('FEEDBACK SUBMITTED SUCCESSFULLY');</script>");
        }
    }
}