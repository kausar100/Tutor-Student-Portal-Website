﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace WebApplication4
{
    public partial class Register : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\UserInfo.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            string acc = DropDownList1.SelectedItem.ToString();
            if (acc == "STUDENT")
            {
                string check = "select count(*) from [Student] where userName =  '" + username.Text + "'";
                SqlCommand command = new SqlCommand(check, conn);
                conn.Open();
                int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                conn.Close();

                if(temp==0)
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into Student values ('" + username.Text + "','" + emailId.Text + "','" + passId.Text + "')";
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    //Response.Write("<script>alert('REGISTRATION COMPLETED SUCCESSFULLY');</script>");
                    Response.Redirect("student_homepage.html");
                }
                else
                {
                    Response.Write("<script>alert('This Username already exist...Try Another');</script>");
                    //Label8.Visible = true;

                    //Label8.Text = "This Username already exist...Try Another";
                }

                
            }
            else if (acc == "TUTOR")
            {
                string check = "select count(*) from [Tutor] where userName =  '" + username.Text + "'";
                SqlCommand command = new SqlCommand(check, conn);
                conn.Open();
                int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                conn.Close();

                if (temp == 0)
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into Tutor values ('" + username.Text + "','" + emailId.Text + "','" + passId.Text + "')";
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    //Response.Write("<script>alert('REGISTRATION COMPLETED SUCCESSFULLY');</script>");
                    Response.Redirect("tutor_homepage.html");
                }
                else
                {
                    Response.Write("<script>alert('This Username already exist...Try Another');</script>");
                    //Label8.Visible = true;

                    //Label8.Text = "This Username already exist...Try Another";
                }


            }
            else
            {
                string check = "select count(*) from [Admin] where userName =  '" + username.Text + "'";
                SqlCommand command = new SqlCommand(check, conn);
                conn.Open();
                int temp = Convert.ToInt32(command.ExecuteScalar().ToString());
                conn.Close();

                if (temp == 0)
                {
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into Admin values ('" + username.Text + "','" + emailId.Text + "','" + passId.Text + "')";
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    //Response.Write("<script>alert('REGISTRATION COMPLETED SUCCESSFULLY');</script>");
                    Response.Redirect("admin_homepage.html");
                }
                else
                {
                    Response.Write("<script>alert('This Username already exist...Try Another');</script>");
                    //Label8.Visible = true;

                    //Label8.Text = "This Username already exist...Try Another";
                }


            }

        }
    }
}